package com.xiangxue.common.views.picturetitleview;

import com.xiangxue.base.customview.BaseCustomViewModel;

public class PictureTitleViewModel extends BaseCustomViewModel {
    public String pictureUrl;
}
