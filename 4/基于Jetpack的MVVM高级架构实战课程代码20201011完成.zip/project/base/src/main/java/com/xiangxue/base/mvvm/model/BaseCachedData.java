package com.xiangxue.base.mvvm.model;

public class BaseCachedData<DATA> {
    public long updateTimeInMillis;
    public DATA data;
}
