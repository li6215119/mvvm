package com.xiangxue.mvx.model;

/**
 * Created by ericmaxwell on 1/19/17.
 */

public class Cell {

    private Player value;

    public Player getValue() {
        return value;
    }

    public void setValue(Player value) {
        this.value = value;
    }
}
