package com.xiangxue.mvx.model;

public enum GameState {
    IN_PROGRESS,
    FINISHED
}