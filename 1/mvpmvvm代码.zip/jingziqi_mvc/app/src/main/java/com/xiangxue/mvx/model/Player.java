package com.xiangxue.mvx.model;

public enum Player {
    X,
    O
}
